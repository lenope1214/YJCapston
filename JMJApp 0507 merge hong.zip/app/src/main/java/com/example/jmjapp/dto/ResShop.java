package com.example.jmjapp.dto;

import java.util.List;

public class ResShop {
    private List<Shop> data;

    public List<Shop> getData() {
        return data;
    }

    public void setData(List<Shop> data) {
        this.data = data;
    }
}
