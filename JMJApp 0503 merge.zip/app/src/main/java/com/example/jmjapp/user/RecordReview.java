package com.example.jmjapp.user;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.jmjapp.R;

public class RecordReview extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_review);
    }
}