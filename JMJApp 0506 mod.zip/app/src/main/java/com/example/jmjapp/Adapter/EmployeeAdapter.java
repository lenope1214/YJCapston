package com.example.jmjapp.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.jmjapp.R;
import com.example.jmjapp.dto.Employee;
import com.example.jmjapp.user.CustomerServiceViewHolder;

import java.util.ArrayList;

import lombok.NonNull;

public class EmployeeAdapter extends RecyclerView.Adapter<EmployeeAdapter.ItemViewHolder> {

    private ArrayList<Employee> recordData;
    public EmployeeAdapter(ArrayList<Employee> recordData) {this.recordData = recordData;}

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_employees_item, parent, false);
        ItemViewHolder holder = new ItemViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Employee record = recordData.get(position);
    }

    @Override
    public int getItemCount() {
        return (recordData==null) ?0:recordData.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder{
        ImageView iv_empitemprofile;
        TextView tv_empitemname;
        TextView tv_empitemphone;
        TextView tv_empitemtime;
        TextView sw_empitemwork;
        View v_emp;

        public ItemViewHolder(@NonNull View itemView){
            super(itemView);
            iv_empitemprofile = itemView.findViewById(R.id.iv_empitemprofile);
            tv_empitemname = itemView.findViewById(R.id.tv_empitemname);
            tv_empitemphone = itemView.findViewById(R.id.tv_empitemphone);
            tv_empitemtime = itemView.findViewById(R.id.tv_empitemtime);
            sw_empitemwork = itemView.findViewById(R.id.sw_empitemwork);
            v_emp = itemView.findViewById(R.id.v_emp);
        }
    }


}
