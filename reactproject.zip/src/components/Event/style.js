import styled from "styled-components";

export const EventWrap = styled.div`
margin-top: 70px;
width: 60%;
margin-left: 20%;

`;