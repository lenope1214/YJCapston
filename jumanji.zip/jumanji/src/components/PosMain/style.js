import styled from "styled-components";

export const PosMainWrap = styled.div`
// background:white;
background:#F2F2F2;
margin-top:70px;
.main-container{
    margin-top:147px;
    height:800px;
}
.main-button1{
position:absolute;
width:150px;
height:150px;
top:30%;
left:39%;
background-color:#61C8FA;
// color:white;
border:0px;
}
.main-button2{
    position:absolute;
    width:150px;
    height:150px;
    top:30%;
    left:51%;
    background-color:#61C8FA;
    border:0px;
}
.main-button3{
    position:absolute;
    width:150px;
    height:150px;
    top:55%;
    left:39%;
    background-color:#61C8FA;
    border:0px;
}
.main-button4{
    position:absolute;
    width:150px;
    height:150px;
    top:55%;
    left:51%;
    background-color:#61C8FA;
    border:0px;
}
.main-button1:hover{
    outline:10px solid #929495;
}
.main-button2:hover{
    outline:10px solid #929495;
}
.main-button3:hover{
    outline:10px solid #929495;
}
.main-button4:hover{
    outline:10px solid #929495;
}

.footer{
    // margin-top:23%;
    // margin-left:45%;
    // color:black;
    position:absolute;
    top:90%;
    left:45%;
}
`