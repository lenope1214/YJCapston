import styled from "styled-components";

export const TablebarWrap = styled.div`
.emp-container{
    padding-top: 145px;
    padding-bottom:0px;
    // padding-left: 550px;
    // transform: translateX(-27%);
    width: 100%;    
    
    // text-align: center;
    // border-bottom: solid 1px black;
}

.header{
    // border-bottom:1px solid black;
    text-align: center;
    // background-color:gray;
    
}
.menu-1{
    position: fixed;
    background-color:#282828;
    color:white;
    border:white;
    position:absolute;
    top:53px;
    left:0px;
    width:100px;
   height:150px;
}
.menu-2{
    position: fixed;
    background-color:#282828;
    color:white;
    border:white;
    position:absolute;
    left:0px;
    top:203px;
    width:100px;
   height:150px;
}
.menu-3{
    position: fixed;
    background-color:#282828;
    color:white;
    border:white;
    position:absolute;
    left:0px;
    top:353px;
    width:100px;
   height:150px;
}
.menu-4{
    position: fixed;
    background-color:#282828;
    color:white;
    border:white;
    position:absolute;
    left:0px;
    top:503px;
    width:100px;
   height:150px;
}
button:hover{
    // background-color:#8AC1F2;
    background-color:#41D1E1;
} 
.menu-bar{
    position:fixed;
}
`