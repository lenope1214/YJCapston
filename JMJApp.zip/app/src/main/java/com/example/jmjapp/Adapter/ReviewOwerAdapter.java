package com.example.jmjapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.jmjapp.R;
import com.example.jmjapp.dto.Review;

import java.util.ArrayList;

public class ReviewOwerAdapter extends RecyclerView.Adapter<ReviewOwerAdapter.ItemViewHolder> {
    Context context;
    ArrayList<Review> mItems;

    public ReviewOwerAdapter(Context context, ArrayList<Review> reviews) {
        this.context = context;
        mItems = reviews;
    }

    public ReviewOwerAdapter(Context context) {
        this.context = context;
    }

    public void setItems(ArrayList<Review> reviews) {
        this.mItems = reviews;
    }

    // 새로운 뷰 홀더 생성
    @Override
    public ReviewOwerAdapter.ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_review_owner_list, parent, false);
        return new ReviewOwerAdapter.ItemViewHolder(view);
    }

    // View 의 내용을 해당 포지션의 데이터로 바꿉니다.
    @Override
    public void onBindViewHolder(final ReviewOwerAdapter.ItemViewHolder holder, final int position) {
        holder.review_owner_userId.setText(mItems.get(position).getUserId() + "님");
        holder.review_owner_content.setText(mItems.get(position).getContent());

        String regDate = mItems.get(position).getRegDate();
        String year = regDate.substring(0, 4);
        String month = regDate.substring(5, 7);
        String day = regDate.substring(8, 10);
        String hour = regDate.substring(11, 13);
        String min = regDate.substring(14, 16);
        holder.review_owner_regDate.setText(month + "월" + day + "일 " + hour + "시" + min + "분");

        Glide.with(context).load("http://3.34.55.186:8088/" + mItems.get(position).getImgUrl()).override(500, 500).into(holder.review_owner_img);

    }

    // 데이터 셋의 크기
    @Override
    public int getItemCount() {
        return mItems == null ? 0 : mItems.size();
    }

    // 커스텀 뷰홀더
    // item layout 에 존재하는 위젯들을 바인딩합니다.
    class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView review_owner_userId, review_owner_regDate, review_owner_content;
        ImageView review_owner_img;

        public ItemViewHolder(View itemView) {
            super(itemView);
            review_owner_userId = itemView.findViewById(R.id.review_owner_userId);
            review_owner_regDate = itemView.findViewById(R.id.review_owner_regDate);
            review_owner_content = itemView.findViewById(R.id.review_owner_content);
            review_owner_img = itemView.findViewById(R.id.review_owner_img);
        }
    }
}
