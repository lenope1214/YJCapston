package com.example.jmjapp.user;

public interface OnTabItemSelectedListener {
    public void onTabSelected(int position);
}
