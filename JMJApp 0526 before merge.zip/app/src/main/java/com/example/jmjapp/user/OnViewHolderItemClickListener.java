package com.example.jmjapp.user;

public interface OnViewHolderItemClickListener {
    void onViewHolderItemClick();
}