package com.example.jmjapp.user;

public interface OnViewHolderItemClickListener1 {
    void onViewHolderItemClick1();
}